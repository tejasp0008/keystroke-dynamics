document.addEventListener('DOMContentLoaded', () => {
    const passwordInput = document.getElementById('password-input');
    const passwordDisplay = document.getElementById('password-display');
    const instructionMessage = document.getElementById('instruction-message');
    const errorMessage = document.getElementById('error-message');
    const typingFeedback = document.getElementById('typing-feedback'); // New element
    const subjectIdInput = document.getElementById('subject-id');
    const resetButton = document.getElementById('reset-button');
    const loadingIndicator = document.getElementById('loading-indicator');
    const resultsDisplay = document.getElementById('results-display'); // New element to hide/show all results

    const resClaimantId = document.getElementById('res-claimant-id');
    const resAuthStatus = document.getElementById('res-auth-status');
    const resJustification = document.getElementById('res-justification');
    const resLstm = document.getElementById('res-lstm');
    const resSvm = document.getElementById('res-svm');
    const resRf = document.getElementById('res-rf');
    const resFinalPred = document.getElementById('res-final-pred');

    const TARGET_PASSWORD = ".tie5Roanl";
    // Derived from 10 H + 9 DD + 9 UD = 28 features for TARGET_PASSWORD
    const EXPECTED_FEATURES_COUNT = 28; 
    
    let sequenceEvents = []; // Stores raw keydown/keyup events in sequence
    let passwordIndex = 0; // Tracks which character in TARGET_PASSWORD we are expecting

    // --- Helper to set status colors ---
    function setStatusColor(element, status) {
        element.classList.remove('status-na', 'status-success', 'status-fail', 'status-info');
        if (status === "Authenticated") {
            element.classList.add('status-success');
        } else if (status === "Not Authenticated" || status.includes("Error") || status.includes("Mismatch")) {
            element.classList.add('status-fail');
        } else if (status.includes("Processing")) {
            element.classList.add('status-info');
        } else {
            element.classList.add('status-na');
        }
    }

    // --- Helper to clear results ---
    function clearResults() {
        resClaimantId.textContent = 'N/A';
        resAuthStatus.textContent = 'N/A';
        resJustification.textContent = 'N/A';
        resLstm.textContent = 'N/A';
        resSvm.textContent = 'N/A';
        resRf.textContent = 'N/A';
        resFinalPred.textContent = 'N/A';

        setStatusColor(resAuthStatus, 'N/A');
        setStatusColor(resLstm, 'N/A');
        setStatusColor(resSvm, 'N/A');
        setStatusColor(resRf, 'N/A');
        setStatusColor(resFinalPred, 'N/A');

        errorMessage.textContent = '';
        errorMessage.classList.add('hidden');
        instructionMessage.textContent = '';
        instructionMessage.classList.add('hidden');

        loadingIndicator.classList.add('hidden');
        resultsDisplay.classList.add('hidden'); // Hide results entirely
    }

    // --- Reset Functionality ---
    function resetTyping() {
        sequenceEvents = [];
        passwordIndex = 0;
        passwordInput.value = "";
        passwordInput.disabled = false;
        
        typingFeedback.textContent = "Ready";
        typingFeedback.classList.remove('typing-active');
        typingFeedback.classList.add('typing-inactive');

        instructionMessage.textContent = `Type the password: "${TARGET_PASSWORD}" and press Enter.`;
        instructionMessage.classList.remove('hidden');
        instructionMessage.classList.add('info-message'); // Ensure info message styling

        clearResults();
        passwordInput.focus();
    }

    resetButton.addEventListener('click', resetTyping);
    resetTyping(); // Initial reset on page load

    // --- Event Listeners for Keystroke Capture ---
    passwordInput.onkeydown = (e) => {
        const now = performance.now();
        const expectedChar = TARGET_PASSWORD[passwordIndex];
        const key = e.key;

        errorMessage.classList.add('hidden'); // Clear previous errors on new input
        instructionMessage.classList.add('hidden'); // Clear info message once typing starts

        if (typingFeedback.textContent === "Ready") {
            typingFeedback.textContent = "Typing...";
            typingFeedback.classList.remove('typing-inactive');
            typingFeedback.classList.add('typing-active');
            clearResults(); // Clear results at start of new typing
        }

        if (key === 'Enter') {
            e.preventDefault(); // Prevent newline
            if (passwordIndex === TARGET_PASSWORD.length) {
                // Password fully typed, process and send
                processKeystrokeSequenceAndSend();
            } else {
                errorMessage.textContent = "Please type the full password before pressing Enter.";
                errorMessage.classList.remove('hidden');
            }
            return;
        }

        if (key === 'Backspace') {
            if (passwordIndex > 0) {
                errorMessage.textContent = "Backspace detected. Please reset and re-type for accurate capture.";
                errorMessage.classList.remove('hidden');
                setStatusColor(errorMessage, "Error");
                setTimeout(resetTyping, 2000); // Auto-reset after a short delay
                return;
            }
        }

        const pressedChar = (key === 'Period') ? '.' : key; 

        if (pressedChar === expectedChar) {
            sequenceEvents.push({ type: 'keydown', char: pressedChar, time: now });
        } else if (pressedChar !== expectedChar && pressedChar.length === 1 && TARGET_PASSWORD.includes(pressedChar)) {
            // Only show mismatch for actual password chars, not shift/alt etc.
            errorMessage.textContent = `Wrong key! Expected '${expectedChar}', got '${pressedChar}'. Please reset and try again.`;
            errorMessage.classList.remove('hidden');
            setStatusColor(errorMessage, "Error");
            setTimeout(resetTyping, 2000);
            return;
        }
    };

    passwordInput.onkeyup = (e) => {
        const now = performance.now();
        const key = e.key;

        if (key === 'Enter' || key === 'Backspace') {
            return; // Handled in keydown
        }

        const releasedChar = (key === 'Period') ? '.' : key;

        if (releasedChar === TARGET_PASSWORD[passwordIndex]) {
            sequenceEvents.push({ type: 'keyup', char: releasedChar, time: now });
            passwordIndex++; // Move to next expected character only on successful keyup
        } else if (releasedChar !== TARGET_PASSWORD[passwordIndex] && releasedChar.length === 1 && TARGET_PASSWORD.includes(releasedChar)) {
            errorMessage.textContent = `Keyup mismatch! Expected '${TARGET_PASSWORD[passwordIndex]}', got '${releasedChar}'. Please reset and try again.`;
            errorMessage.classList.remove('hidden');
            setStatusColor(errorMessage, "Error");
            setTimeout(resetTyping, 2000);
        }
    };
    
    function processKeystrokeSequenceAndSend() {
        if (passwordIndex !== TARGET_PASSWORD.length || sequenceEvents.length < TARGET_PASSWORD.length * 2) { // Need at least 2 events per char
            errorMessage.textContent = "Invalid password sequence captured. Please reset and try again.";
            errorMessage.classList.remove('hidden');
            setStatusColor(errorMessage, "Error");
            return;
        }

        loadingIndicator.classList.remove('hidden');
        resultsDisplay.classList.add('hidden'); // Hide results until new ones are ready
        passwordInput.disabled = true;
        
        typingFeedback.textContent = "Processing...";
        typingFeedback.classList.remove('typing-active');
        typingFeedback.classList.add('typing-inactive'); // Indicate not actively typing

        const featuresToSend = [];
        const keydownTimes = {}; 
        const keyupTimes = {};   

        // Filter out any unexpected keys or duplicates for robustness
        const uniqueSequenceEvents = [];
        const seenEvents = new Set(); // To track keydown/keyup for specific char and time

        sequenceEvents.forEach(event => {
            const eventId = `${event.type}-${event.char}-${event.time}`;
            if (!seenEvents.has(eventId)) {
                uniqueSequenceEvents.push(event);
                seenEvents.add(eventId);
            }
        });

        // Ensure events are sorted by time (important for DD/UD)
        uniqueSequenceEvents.sort((a, b) => a.time - b.time);

        // Populate keydownTimes and keyupTimes accurately
        let lastCharDownTime = {};
        let lastCharUpTime = {};

        uniqueSequenceEvents.forEach(event => {
            if (event.type === 'keydown') {
                keydownTimes[event.char] = event.time;
                lastCharDownTime[event.char] = event.time; // Keep track of the latest keydown for a char
            } else if (event.type === 'keyup') {
                keyupTimes[event.char] = event.time;
                lastCharUpTime[event.char] = event.time; // Keep track of the latest keyup for a char
            }
        });


        // Calculate H (Hold Times)
        TARGET_PASSWORD.split('').forEach(char => {
            const H_time = keyupTimes[char] - keydownTimes[char];
            featuresToSend.push({ key: `H.${char}`, interval: Math.round(H_time) });
        });

        // Calculate DD (Keydown-Keydown) and UD (Keyup-Keydown)
        for (let i = 0; i < TARGET_PASSWORD.length - 1; i++) {
            const char1 = TARGET_PASSWORD[i];
            const char2 = TARGET_PASSWORD[i + 1];

            // DD.char1.char2
            const DD_time = keydownTimes[char2] - keydownTimes[char1];
            featuresToSend.push({ key: `DD.${char1}.${char2}`, interval: Math.round(DD_time) });

            // UD.char1.char2
            const UD_time = keydownTimes[char2] - keyupTimes[char1];
            featuresToSend.push({ key: `UD.${char1}.${char2}`, interval: Math.round(UD_time) });
        }
        
        if (featuresToSend.length !== EXPECTED_FEATURES_COUNT) {
            errorMessage.textContent = `Feature extraction error: Expected ${EXPECTED_FEATURES_COUNT} features, but got ${featuresToSend.length}. Please reset and try again.`;
            errorMessage.classList.remove('hidden');
            setStatusColor(errorMessage, "Error");
            loadingIndicator.classList.add('hidden');
            console.error("Features mismatch:", featuresToSend);
            return;
        }

        // Send to backend
        const subjectId = subjectIdInput.value || 'unknown_subject';
        const payload = {
            subject_id: subjectId,
            keystrokes: featuresToSend
        };
        
        console.log("Sending payload:", payload);

        fetch('/predict', { // Ensure this matches your backend URL if running on different port/host
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        })
        .then(response => {
            loadingIndicator.classList.add('hidden');
            resultsDisplay.classList.remove('hidden'); // Show results area
            if (!response.ok) {
                return response.json().then(errorData => {
                    throw new Error(errorData.detail || 'Network response was not ok');
                });
            }
            return response.json();
        })
        .then(data => {
            console.log('Success:', data);
            resClaimantId.textContent = data.claimant_subject_id;
            resAuthStatus.textContent = data.system_authentication_status_for_claimant;
            setStatusColor(resAuthStatus, data.system_authentication_status_for_claimant);
            
            resJustification.textContent = data.justification;
            
            resLstm.textContent = data.predictions.LSTM;
            setStatusColor(resLstm, data.predictions.LSTM);
            
            resSvm.textContent = data.predictions.SVM;
            setStatusColor(resSvm, data.predictions.SVM);
            
            resRf.textContent = data.predictions.RandomForest;
            setStatusColor(resRf, data.predictions.RandomForest);
            
            resFinalPred.textContent = data.final_prediction_for_target_subject;
            setStatusColor(resFinalPred, data.final_prediction_for_target_subject);

            instructionMessage.textContent = "Results displayed. Click 'Reset Demo' to try again.";
            instructionMessage.classList.remove('hidden');
            instructionMessage.classList.add('info-message');

            typingFeedback.textContent = "Finished";
            typingFeedback.classList.remove('typing-active');
            typingFeedback.classList.add('typing-inactive');

        })
        .catch((error) => {
            console.error('Error:', error);
            loadingIndicator.classList.add('hidden');
            resultsDisplay.classList.add('hidden'); // Hide results if error
            errorMessage.textContent = `Error: ${error.message}. Please check console for details.`;
            errorMessage.classList.remove('hidden');
            setStatusColor(errorMessage, "Error");
            
            instructionMessage.textContent = "An error occurred. Click 'Reset Demo' to try again.";
            instructionMessage.classList.remove('hidden');
            instructionMessage.classList.add('info-message'); // Use info style for general error message guidance
            
            typingFeedback.textContent = "Error";
            typingFeedback.classList.remove('typing-active');
            typingFeedback.classList.add('typing-inactive');
        });
    }
});